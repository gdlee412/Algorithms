#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#define MAXCITY 26

// structure for plane flight path
typedef struct flightPath
{
    char currentCity;        // name of current City
    int departureTime;       // time of departure from current City
    struct flightPath *prev; //previous flight
    struct flightPath *next; // next city (destination city)
} flightPath;

// rbtree structure
typedef struct Rbtree
{
    char name[20];    // passenger name
    int key;          // rbtree id
    char source;      // source city (beginning city)
    char destination; // destination city
    struct flightPath *path; //flight path
    // rbtree pointers
    struct Rbtree *left;
    struct Rbtree *right;
    struct Rbtree *parent;
    // rbtree node color
    enum{Red, Black} color;
} rbtree;

// global variable to store number of successful inserts
int successful_insert = 0;

// function to randomize city graph and departure times
void randomize_city_graph(int city_graph[26][26])
{
    int i, j;          // iteration variables
    int connected_city_count[26] = {0,0,};  //count number of connected cities per city
    srand(time(NULL)); // random seed

    for(i = 0; i < MAXCITY; i++)
    {
        int required_connections = 10;   //required number of connections per city
        // check number of already connected cities
        for(j = 0; j < MAXCITY; j++)
        {
            //if a connection already exists for the city
            if(city_graph[i][j] != -1)
            {
                //reduce the required connections
                required_connections--;
            }
        }

        // randomize remaining connections
        for(j = 0; j < required_connections; j++)
        {
            //get a random city
            int random_city = rand() % MAXCITY;

            //if random city is the same as the current city
            //or if a pathway to random city already exists
            if(random_city == i || city_graph[i][random_city] != -1)
            {
                //restart current iteration
                j--;
            }
            //if the city has 14 connected cities (max is 14)
            else if(connected_city_count[random_city] == 14)
            {
                j--;
            }
            //else, change graph value to 0, bidirectionally
            else
            {
                city_graph[i][random_city] = 0;
                city_graph[random_city][i] = 0;
                connected_city_count[i]++;
                connected_city_count[random_city]++;
            }
        }

        // randomize departure time
        for(j = 0; j < MAXCITY; j++)
        {
            //if city connection exists ( != -1)
            if(city_graph[i][j] != -1)
            {
                int random_time = rand() % 24;  //random time variable for each city connection
                //set random_time as the value of city_connection_graph
                city_graph[i][j] = random_time;
            }
        }
    }    
}

// function to check if plane flight exists
int check_plane_flight(flightPath** path, int city_graph[26][26], char source, char destination)
{
    //temp pathway to find source to destination
    flightPath* pathway = (flightPath*) malloc(sizeof(flightPath));
    pathway->prev = NULL;
    int visited[26] = {0,0,};   //array to check if already visited
    int source_int = source - 97;   //int version of source
    int final_dest_int = destination - 97;
    int dest_int = destination - 97; //int version of destination
    char dest;

    //if source and destination are the same
    if(source_int == final_dest_int)
    {
        return 0;
    }

    // visit source in visited array
    visited[source_int] = 1;
    
    //if there is direct path from source to destination
    if(city_graph[source_int][final_dest_int] != -1)
    {
        //just return the information of source to destination
        pathway->currentCity = source;
        pathway->departureTime = city_graph[source_int][final_dest_int];
        pathway->next = NULL;
        *path = pathway;

        //return 1 (true)
        return 1;
    }
    
    //while loop to find path
    while(dest != destination ||  pathway->departureTime >= 23)
    {
        //time min
        int time_min;

        //if there is a previous path
        if(pathway->prev != NULL)
        {
            //the earliest time possible is 1 hour after the previous path
            time_min = pathway->prev->departureTime + 1;
            //if there is path directly going to the destination
            if(city_graph[source_int][final_dest_int] != -1 && city_graph[source_int][final_dest_int] >= time_min)
            {
                dest = final_dest_int + 97;
                dest_int = final_dest_int;
            }
            //if no direct path exists, just use for loop
            else
            {
                //min
                int min = 24;
                for(int i = 0; i < MAXCITY; i++)
                {
                    //there is a path and if time is minimum possible
                    if(city_graph[source_int][i] != -1 && city_graph[source_int][i] < min)
                    {
                        //if never visited yet and can still ride
                        if(visited[i] != 1 && city_graph[source_int][i] >= time_min)
                        {
                            //change min
                            time_min = city_graph[source_int][i];
                            dest = i + 97;
                            dest_int = i;
                        }
                    }
                }
            }
        }
        //first time in the while loop
        else
        {
            time_min = 24;
            //find path with shortest destination
            for(int i = 0; i < MAXCITY; i++)
            {
                //there is a path and if time is minimum possible
                if(city_graph[source_int][i] != -1 && city_graph[source_int][i] < time_min)
                {
                    
                    //if never visited yet
                    if(visited[i] != 1)
                    {
                        //change min
                        time_min = city_graph[source_int][i];
                        dest = i + 97;
                        dest_int = i;
                    }
                }
            }
        }

        //set pathway values
        pathway->currentCity = source_int + 97;
        //departure time
        pathway->departureTime = city_graph[source_int][dest_int];

        //the last one found will be visited
        visited[dest_int] = 1;
        //new source for next iteration will be current dest
        source_int = dest_int;

        //if destination is reached, break
        if(dest == destination)
        {
            //find the first source
            while(pathway->prev != NULL)
            {
                pathway = pathway->prev;
            }
            //set path to first source
            *path = pathway;

            return 1;
        }

        //create temp
        //allocate memory for new path
        flightPath* temp = (flightPath*)malloc(sizeof(flightPath));
        temp->next = NULL;
        temp->prev = pathway;
        //connect the nodes
        pathway->next = temp;
        //move to next path
        pathway = pathway->next;
    }

    return 0;
}

//print flight path
void printFlight(flightPath *path) 
{
    //temporary list to store linked list values
    flightPath* temp;
    temp = path;

    while (temp) 
    {
        //print then go to next city
        if(temp->departureTime < 12)
        {
            //if time is 0, print 12am
            if(temp->departureTime == 0)
            {
                printf(", %c(12am)", temp->currentCity);
            }
            else
            {
                printf(", %c(%dam)", temp->currentCity, temp->departureTime);
            }
        }
        else
        {
            //if time is 12, print 12pm
            if(temp->departureTime == 12)
            {
                printf(", %c(12pm)", temp->currentCity);
            }
            else
            {
                printf(", %c(%dpm)", temp->currentCity, temp->departureTime - 12);
            }
        }
        //go to next city
        temp = temp->next;
    }
    printf("\n");
}

// print red black tree
void print_inorder_rbtree(rbtree *tree)
{
    if (tree)
    {
        print_inorder_rbtree(tree->left);
        printf("%d", tree->key);
        if (tree->color == 0)
        {
            printf("[R] ");
        }
        else
        {
            printf("[B] ");
        }
        print_inorder_rbtree(tree->right);
    }
}

// left rotate
void rb_left_rotate(rbtree **tree, rbtree *x)
{
    // rightchild is right node of x
    rbtree *rightchild = x->right;

    // set x's right subtree to rightchild's left subtree
    x->right = rightchild->left;

    // link x as parent
    if (rightchild->left != NULL)
    {
        rightchild->left->parent = x;
    }
    // link x's parent to rightchild
    rightchild->parent = x->parent;

    // if x is root
    if (x->parent == NULL)
    {
        // set rightchild as root
        (*tree) = rightchild;
    }
    // else
    else
    {
        // if x is left node
        if (x == x->parent->left)
        {
            // set rightchild as left node
            x->parent->left = rightchild;
        }
        // else right
        else
        {
            // set rightchild as right node
            x->parent->right = rightchild;
        }
    }
    // connect x and rightchild
    rightchild->left = x;
    x->parent = rightchild;
}

// right rotate
void rb_right_rotate(rbtree **tree, rbtree *x)
{
    // leftchild is left node of x
    rbtree *leftchild = x->left;

    // set x's right subtree to leftchild's left subtree
    x->left = leftchild->right;

    // link x as parent
    if (leftchild->right != NULL)
    {
        leftchild->right->parent = x;
    }
    // link x's parent to leftchild
    leftchild->parent = x->parent;

    // if x is root
    if (x->parent == NULL)
    {
        // set leftchild as root
        (*tree) = leftchild;
    }
    // else
    else
    {
        // if x is right node
        if (x == x->parent->right)
        {
            // set leftchild as right node
            x->parent->right = leftchild;
        }
        // else x is left node
        else
        {
            // set leftchild as left node
            x->parent->left = leftchild;
        }
    }
    // connect x and leftchild
    leftchild->right = x;
    x->parent = leftchild;
}

// insert fixup
void rb_insert_fixup(rbtree **tree, rbtree *newnode)
{
    // temp node root to store main tree
    rbtree *root = *tree;

    // while red black tree is not correct
    while ((newnode != root) && (newnode->parent->color == 0) && (newnode->color != 1))
    {
        // uncle node
        rbtree *uncle = NULL;
        // if newnode's parent is a left node
        if (newnode->parent == newnode->parent->parent->left)
        {
            // uncle will be right node
            uncle = newnode->parent->parent->right;
            // if uncle node is red: CASE 1
            if ((uncle != NULL) && (uncle->color == 0))
            {
                // set parent and uncle to black
                newnode->parent->color = 1;
                uncle->color = 1;
                // set grandparent to red
                newnode->parent->parent->color = 0;
                // newnode's grandparent becomes z
                newnode = newnode->parent->parent;
            }
            // else, case 2 or 3
            else
            {
                // if newnode is a right node: CASE 2
                if (newnode == newnode->parent->right)
                {
                    // left rotate on newnode's parent
                    newnode = newnode->parent;
                    rb_left_rotate(tree, newnode);
                }

                // CASE 3
                // recolor parent and grandparent
                newnode->parent->color = 1;
                newnode->parent->parent->color = 0;
                // right rotate on grandparent
                rb_right_rotate(tree, newnode->parent->parent);
            }
        }
        // else parent of newnode is right node
        else
        {
            // uncle is left node
            uncle = newnode->parent->parent->left;
            // if uncle is red: CASE 1
            if ((uncle != NULL) && uncle->color == 0)
            {
                // recolor nodes
                newnode->parent->color = 1;
                uncle->color = 1;
                newnode->parent->parent->color = 0;
                // z's grandparent becomes z
                newnode = newnode->parent->parent;
            }
            // else
            else
            {
                // if newnode's parent is a left node: CASE 2
                if (newnode == newnode->parent->left)
                {
                    // right rotate on newnode's parent
                    newnode = newnode->parent;
                    rb_right_rotate(tree, newnode);
                }

                // recolor parent and grandparent node
                newnode->parent->color = 1;
                newnode->parent->parent->color = 0;
                // left rotate on newnode's grandparent
                rb_left_rotate(tree, newnode->parent->parent);
            }
        }
    }
    // set root's color to black
    (*tree)->color = 1;
}

// insert function
void rb_insert(rbtree **tree, flightPath *path, char name[20], int key, char source, char dest)
{
    // newnode to store new information
    rbtree *newnode;
    // dynamically allocate size to newnode
    newnode = (rbtree *)malloc(sizeof(rbtree));
    // give newnode the necessary information
    for (int i = 0; name[i] != '\0'; i++)
    {
        newnode->name[i] = name[i];
    }
    newnode->path = path;
    newnode->key = key;
    newnode->source = source;
    newnode->destination = dest;

    rbtree *xparent = NULL; // x's parent
    rbtree *x = *tree;      // x set to root

    // while x is not NULL
    while (x != NULL)
    {
        // set y as x
        xparent = x;
        // if newnode key is less than x's key
        if (newnode->key < x->key)
        {
            // move to left node
            x = x->left;
        }
        // else greater
        else if (newnode->key > x->key)
        {
            // move to right node
            x = x->right;
        }
        // found the same value
        else
        {
            // if ever key already exists, print unsuccessful and return
            printf("Unsuccessful insertion\n\n");
            return;
        }
    }
    // set parent of newnode to xparent
    newnode->parent = xparent;

    // print inorder rbtree before insertion
    printf("Before insertion:\n");
    print_inorder_rbtree(*tree);
    printf("\n");

    // if xparent is NULL: tree is empty
    if (xparent == NULL)
    {
        // set newnode as root
        *tree = newnode;
    }
    // else if new key is less than xparent key
    else if (newnode->key < xparent->key)
    {
        // set newnode as left of xparent
        xparent->left = newnode;
    }
    // else if greater
    else if (newnode->key > xparent->key)
    {
        // set newnode as right of xparent
        xparent->right = newnode;
    }
    // initialize newnode values
    newnode->left = NULL;
    newnode->right = NULL;
    newnode->color = 0;

    // insert fixup call
    rb_insert_fixup(tree, newnode);
    successful_insert++;

    // print rbtree after insert
    printf("After insertion:\n");
    print_inorder_rbtree(*tree);
    printf("\n\n");
}

// finding successor
rbtree *successor(rbtree *x)
{
    // if node has a right child
    if (x->right != NULL)
    {
        rbtree *y = x->right;

        // find minimum
        while (y->left != NULL)
        {
            y = y->left;
        }
        // return minimum node
        return y;
    }
    // else
    else
    {
        // y set as x's parent
        rbtree *y = x->parent;
        // keep moving up
        while (y != NULL && x == y->right)
        {
            x = y;
            y = y->parent;
        }
        // return successor
        return y;
    }
}

//delete fixup
void rb_delete_fixup(rbtree** tree, rbtree* node)
{
    //temp node root to store main tree
    rbtree* root = *tree;

    //while loop for fixup
    while(node != root && node->color == 1)
    {
        //brother node
        rbtree* brother = NULL;
        //if node is left of parent
        if(node == node->parent->left)
        {
            //brother is right child
            brother = node->parent->right;

            //if color of brother is red: CASE 1
            if(brother->color == 0)
            {
                //change color of brother and parent
                brother->color = 1;
                node->parent->color = 0;
                //left rotate
                rb_left_rotate(tree, node->parent);
                brother = node->parent->right;
            }
            //if children of brother are all black: CASE 2
            else if(brother->left->color == 1 && brother->right->color == 1)
            {
                //change brother color to red
                brother->color = 0;
                node = node->parent;
            }
            //else, only one is black or both are red
            else
            {
                //if brother's right child is black: CASE 3
                if(brother->right->color == 1)
                {
                    //set brother's left child to black
                    //set brother's color to red
                    brother->left->color = 1;
                    brother->color = 0;
                    //right rotate on brother
                    rb_right_rotate(tree, brother);
                    brother = node->parent->right;
                }

                //brother's left child is black: CASE 4
                //change brother and parent color
                brother->color = node->parent->color;
                node->parent->color = 1;
                brother->right->color = 1;
                //left rotate on parent of node
                rb_left_rotate(tree, node->parent);
                //set to root to leave while loop
                node = root;
            }
        }
        //parent is right child
        else
        {
            //brother is left child
            brother = node->parent->left;

            //if color of brother is red: CASE 1
            if(brother->color == 0)
            {
                //change color of brother and parent
                brother->color = 1;
                node->parent->color = 0;
                //right rotate
                rb_right_rotate(tree, node->parent);
                brother = node->parent->left;
            }
            //if children of brother are all black: CASE 2
            if(brother->left->color == 1 && brother->right->color == 1)
            {
                //change brother color to red
                brother->color = 0;
                node = node->parent;
            }
            //else, only one is black or both are red
            else
            {
                //if brother's left child is black: CASE 3
                if(brother->left->color == 1)
                {
                    //set brother's right child to black
                    //set brother's color to red
                    brother->right->color = 1;
                    brother->color = 0;
                    //left rotate on uncle
                    rb_left_rotate(tree, brother);
                    brother = node->parent->left;
                }

                //brother's right child is black: CASE 4
                //change brother and parent color
                brother->color = node->parent->color;
                node->parent->color = 1;
                brother->left->color = 1;
                //right rotate on parent of node
                rb_right_rotate(tree, node->parent);
                //set to root to exit while loop
                node = root;
            }
        }
    }

    //set color of root to black
    node->color = 1;
}

//delete node
void rb_delete(rbtree** tree, int deleteval)
{
    rbtree* x = *tree;  //main tree for branching out
    rbtree* child;
    child->color = 1;
    rbtree* y = NULL;
    rbtree* node_to_delete = NULL;  //stores the node to be deleted

    //if tree is empty, just exit
    if(!x)
    {
        printf("Reservation tree is empty.\n");
        return;
    }
    //while loop to find node to delete
    while(x != NULL)
    {
        //if deleteval is greater than x
        if(deleteval > x->key)
        {
            //go to right
            x = x->right;
        }
        //else if less than x
        else if(deleteval < x->key)
        {
            //go to left
            x = x->left;
        }
        //if found value
        else if(deleteval == x->key)
        {
            //equate node and break
            node_to_delete = x;
            break;
        }
    }

    //leave if node_to_delete is still NULL
    if(node_to_delete == NULL)
    {
        printf("This reservation does not exist.\n\n");
        return;
    }

    //print inorder rbtree before deletion
    printf("Before deletion:\n");
    print_inorder_rbtree(*tree);
    printf("\n");

    //determine which node y to splice out
    if(node_to_delete->left == NULL || node_to_delete->right == NULL)
    {
        y = node_to_delete;
    }
    //find successor
    else
    {
        y = successor(node_to_delete);
    }

    //child is set to non-NULL child of y, or NULL if y has no children
    if(y->left != NULL)
    {
        child = y->left;
    }
    else
    {
        child = y->right;
    }
    //remove y by manipulating pointers of parent and x
    if(child != NULL)
    {
        child->parent = y->parent;
    }

    //if parent of y is null, y is root so delete
    if(y->parent == NULL)
    {
        (*tree) = child;
    }
    //else
    else
    {
        //if y is a left child
        if(y == y->parent->left)
        {
            //connect x to left of y's parent
            y->parent->left = child;

        }
        //y is right child
        else
        {
            //connect y's child to the right of y's parent
            y->parent->right = child;
        }
    }
    //if y not equal to node to delete
    if(y->key != node_to_delete->key)
    {
        //copy y's values to z
        node_to_delete->key = y->key;
    }

    //delete fixup call
    if(child != NULL)
    {
        rb_delete_fixup(tree, child);
    }
    else
    {
        rb_delete_fixup(tree, y->parent);
    }

    //print rbtree after deletion
    printf("After deletion:\n");
    print_inorder_rbtree(*tree);
    printf("\n\n");
}

int main()
{
    int city_graph[MAXCITY][MAXCITY]; // 2D array to store the connected cities
    //(-1 = not connected / 0 - 23 = departure time)
    flightPath *path;
    rbtree *tree = NULL; // main red black tree
    char name[20];       // passenger name
    int key = 1;         // key for node id
    char source;         // source city
    char destination;    // destination city

    //initialize city_connection_graph
    for(int i = 0; i < MAXCITY; i++)
    {
        for(int j = 0; j < MAXCITY; j++)
        {
            //set element value to -1
            city_graph[i][j] = -1;
        }
    }

    // randomize plane graph
    randomize_city_graph(city_graph);

    //while loop for 10 successful inserts
    while (successful_insert != 10)
    {
        //request for input
        printf("Airline Reservation System\n");
        printf("--------------------------------\n");
        printf("Welcome to the Airline Reservation System.\n");
        printf("Please enter your name, source city, destination city, and date of departure\n");
        printf("With the following format:\n");
        printf("Name, source, destination\n");
        printf("--------------------------------\n");
        printf("Example: Daniel, a, g\n");
        printf("--------------------------------\n");
        printf("Enter your input: ");
        scanf("%[^,], %c, %c", name, &source, &destination);

        // check plane flight function
        //if plane flight was successfully found
        if(check_plane_flight(&path, city_graph, source, destination) == 1)
        {
            //print success with success information
            printf("Plane Flight Successfully Reserved!!\n");
            printf("--------------------------------\n");
            printf("Here are your flight details:\n");
            printf("%s, %c, %c", name, source, destination);
            //print the flight path
            printFlight(path);
            printf("\n");

            //insert in rb tree
            rb_insert(&tree, path, name, key, source, destination);
            //increment key
            key++;
        }
        else
        {
            printf("Unfortunately, there are no flight path for you.\n\n");
        }
    }

    printf("*******************DELETION************************\n");

    
    for(int i = 4; i < 9; i++)
    {
        rb_delete(&tree, i);
    }

    return 0;
}